﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(Sito_pittura.Startup))]
namespace Sito_pittura
{
    public partial class Startup {
        public void Configuration(IAppBuilder app) {
            ConfigureAuth(app);
        }
    }
}
