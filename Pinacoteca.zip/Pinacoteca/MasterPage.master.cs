﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class MasterPage : System.Web.UI.MasterPage
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnlogout_Click(object sender, EventArgs e)
    {
        if (Convert.ToBoolean(Session["logged"]))
        {
            Session.Remove("logged");
            Response.Redirect("Login.aspx");
        }
        else if (Convert.ToBoolean(Session["Adminlogged"]))
        {
            Session.Remove("Adminlogged");
            Response.Redirect("Login.aspx");
        }
    }
}
