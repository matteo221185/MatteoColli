﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Descrizione di riepilogo per Film
/// </summary>
public class Film
{
    public string Copertina { get; set; }
    public string Titolo { get; set; }
    public int Anno { get; set; }
    public string Durata { get; set; }
    public string Audio { get; set; }
    public double Prezzo { get; set; }

    public Film ()
    {
        Database.lstFilm.Add(this);
    }

}