﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Descrizione di riepilogo per Amministratori
/// </summary>
public class Amministratori
{
    public string Username { get; set; }
    public string Password { get; set; }
}