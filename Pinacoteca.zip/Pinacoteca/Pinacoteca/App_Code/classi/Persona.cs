﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Descrizione di riepilogo per Persona
/// </summary>
public class Persona
{
    public string Nome { get; set; }
    public string Cognome { get; set; }
    public string Citta { get; set; }
    public string DataNascita { get; set; }
    public string Indirizzo { get; set; }
    public int Cap { get; set; }
    public double Credito { get; set; }
    public string Username { get; set; }
    public string Password { get; set; }
}