﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Descrizione di riepilogo per Citta
/// </summary>
public class Citta
{
        public string nome { get; set; }
}