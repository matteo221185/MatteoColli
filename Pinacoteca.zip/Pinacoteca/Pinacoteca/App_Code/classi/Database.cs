﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Descrizione di riepilogo per Database
/// </summary>
public static class Database
{
    public static List<Persona> lstUtenti = new List<Persona>();
    public static List<Amministratori> lstAmministratori = new List<Amministratori>()
    {
            new Amministratori ()
            {
                Username ="2", Password ="2"
            }
    };
    public static List<Film> lstFilm = new List<Film>();
    public static List<Film> OttieniFilm()
    {
        Film f = new Film()
        { Titolo = "Avengers", Copertina = "Avengers.jpg", Anno=2001, Audio = "5.1", Prezzo = 15.00 };
        f = new Film()
        { Titolo = "Avengers 2 - I Vendicatori", Copertina = "Avengers_2_I_vendicatori.jpg", Anno = 2001, Audio = "5.1", Prezzo = 15.00 };
        f = new Film()
        { Titolo = "Avengers 3 - Infinite Wars", Copertina = "Avengers_3_Infinite_Wars.jpg", Anno = 2001, Audio = "5.1", Prezzo = 15.00 };
        f = new Film()
        { Titolo = "Spiderman 1", Copertina = "Spiderman1.jpg", Anno = 2001, Audio = "5.1", Prezzo = 15.00 };
        f = new Film()
        { Titolo = "Spiderman 2", Copertina = "Spiderman2.jpg", Anno = 2001, Audio = "5.1", Prezzo = 15.00 };
        f = new Film()
        { Titolo = "Thor 1", Copertina = "Thor_1.jpg", Anno = 2001, Audio = "5.1", Prezzo = 15.00 };
        f = new Film()
        { Titolo = "Thor 2 - The Dark World", Copertina = "Thor_2_The_Dark_World.jpg", Anno = 2001, Audio = "5.1", Prezzo = 15.00 };
        f = new Film()
        { Titolo = "Thor 3 - Ragnarok", Copertina = "Thor_3_Ragnarok.jpg", Anno = 2001, Audio = "5.1", Prezzo = 15.00 };
        f = new Film()
        { Titolo = "Van Gogh", Copertina = "van_gogh_cafe.jpg", Anno = 1850, Prezzo = 15000000 };

        return lstFilm;
    }
}
