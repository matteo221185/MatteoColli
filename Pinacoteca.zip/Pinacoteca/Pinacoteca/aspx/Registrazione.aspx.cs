﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Videoteca.aspx
{
    public partial class Registrazione : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                List<Citta> lstCitta = new List<Citta>();

                Citta c1 = new Citta();
                c1.nome = "Torino";
                lstCitta.Add(c1);

                Citta c2 = new Citta();
                c2.nome = "Trapani";
                lstCitta.Add(c2);

                Citta c3 = new Citta();
                c3.nome = "Milano";
                lstCitta.Add(c3);

                ddlCitta.DataSource = lstCitta;
                ddlCitta.DataTextField = "Nome";
                ddlCitta.DataBind();
               
            }
        }

        protected void Registrati_Click(object sender, EventArgs e)
        {
            Persona P1 = new Persona();
            P1.Nome = txtNome.Text;
            P1.Cognome = txtCognome.Text;
            P1.Cap = Convert.ToInt32(txtCap.Text);
            P1.Credito = Convert.ToDouble(txtCredito.Text);
            P1.Indirizzo = txtIndirizzo.Text;
            P1.DataNascita = txtDataNascita.Text;
            P1.Citta = ddlCitta.SelectedItem.Text;
            P1.Username =txtUsername.Text;
            P1.Password = txtPassword.Text;
            Database.lstUtenti.Add(P1);
            Response.Redirect("Login.aspx");
        }
    }
}