﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class aspx_Amministratore : System.Web.UI.Page
{

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Convert.ToBoolean(Session["Adminlogged"]))
            Response.Redirect("Login.aspx");

        foreach (Persona pp in Database.lstUtenti)
        {
            lblElenco.Text += "Nome: " + pp.Nome + "<br/>";
            lblElenco.Text += "cognome: " + pp.Cognome + "<br/>";
            lblElenco.Text += "Nascita: " + pp.DataNascita + "<br/>";
            lblElenco.Text += "citta: " + pp.Citta + "<br/>";
            lblElenco.Text += "indirizzo: " + pp.Indirizzo + "<br/>";
            lblElenco.Text += "Cap: " + pp.Cap + "<br/>";
            lblElenco.Text += "Credito: " + pp.Credito + "<br/>" + "<br/>";
        }
    }
}