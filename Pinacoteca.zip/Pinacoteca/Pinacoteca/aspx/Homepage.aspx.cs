﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

    public partial class aspx_Homepage : System.Web.UI.Page
    {
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Convert.ToBoolean(Session["logged"]))
        {
            Response.Redirect("Login.aspx");
        }
        if (!Page.IsPostBack)
        {
            Database.OttieniFilm();
            Persona p = (Persona)Session["utente"];
            lblConto.Text = "il conto è: " + Convert.ToString(Math.Round(p.Credito, 2)) + "€";
        }
        foreach (Film f in Database.lstFilm)
        {
            TableRow tr1 = new TableRow();
            TableRow tr2 = new TableRow();
            TableRow tr3 = new TableRow();
            TableRow tr4 = new TableRow();
            TableRow tr5 = new TableRow();

            TableCell tc1 = new TableCell();
            TableCell tc2 = new TableCell();
            TableCell tc3 = new TableCell();
            TableCell tc4 = new TableCell();
            TableCell tc5 = new TableCell();
            TableCell tc6 = new TableCell();

            tc1.RowSpan = 5;
            tc1.Text = string.Format("<img src='../img/" + f.Copertina + "'style='max-width: 200px;' />");
            tc2.Text = "Titolo: " + f.Titolo;
            tr1.Cells.Add(tc1);
            tr1.Cells.Add(tc2);
            tblFilm.Rows.Add(tr1);

            tc3.Text = "Anno: " + f.Anno;
            tr2.Cells.Add(tc3);
            tblFilm.Rows.Add(tr2);

            tc4.Text = "Audio: " + f.Audio;
            tr3.Cells.Add(tc4);
            tblFilm.Rows.Add(tr3);

            tc5.Text = "Prezzo: " + f.Prezzo + "€";
            tr4.Cells.Add(tc5);
            tblFilm.Rows.Add(tr4);

            Button btnAcquista = new Button();
            btnAcquista.Text = "Acquista";
            tc6.Controls.Add(btnAcquista);
            btnAcquista.CssClass = "btn btn-primary";
            btnAcquista.CommandArgument = Convert.ToString(f.Prezzo);
            btnAcquista.Click += new System.EventHandler(this.btnAcquistaClik);
            //Label lblNoCredito = new Label();
            //lblNoCredito.Enabled = false;
            //tc6.Controls.Add(lblNoCredito);
            tr5.Cells.Add(tc6);
            tblFilm.Rows.Add(tr5);
        }
    }
    public void btnAcquistaClik(object sender, EventArgs e)
    {
        Button b = (Button)sender;
        Persona p = (Persona)Session["utente"];     //cast

        if (!(p.Credito < Convert.ToDouble(b.CommandArgument)))
        {
            p.Credito -= Convert.ToDouble(b.CommandArgument);
            lblConto.Text = "il conto è: " + Convert.ToString(Math.Round(p.Credito, 2)) + "€";
        }
        else
        {
            txtRicarica.Text = "ricarica! credito insufficiente.";
            //Label l = (Label)sender;
            // l.Text = "credito insufficiente!";
            // l.Enabled = true;
        }
    }

    protected void btnRicarica_Click(object sender, EventArgs e)
    {
        Persona p = (Persona)Session["utente"];
        if (!(txtRicarica.Text == ""))
        {
            //Label l = (Label)sender;
            p.Credito = p.Credito + Convert.ToDouble(txtRicarica.Text);
            lblConto.Text = "il conto è: " + Convert.ToString(Math.Round(p.Credito, 2)) + "€";
            txtRicarica.Text = "";
            //l.Enabled = false;
        }
    }
}