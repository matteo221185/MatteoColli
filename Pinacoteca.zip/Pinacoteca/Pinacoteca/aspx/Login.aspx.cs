﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Videoteca.aspx
{
    public partial class Login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Convert.ToBoolean(Session["logged"]))
                Response.Redirect("Home.aspx");

            if (Convert.ToBoolean(Session["Adminlogged"]))
                Response.Redirect("Amministratore.aspx");
        }

        protected void btnLogin_Click(object sender, EventArgs e)
        {
            foreach (Amministratori a in Database.lstAmministratori)
            {
                if (txtUsername.Text == a.Username && txtPassword.Text == a.Password)
                {
                    lblEsito.Text = "";
                    Session.Add("Adminlogged", true);
                    Session.Add("PassUtente", txtPassword.Text);

                    Response.Redirect("Amministratore.aspx");
                }
                else
                {
                    lblEsito.Text = "Devi Registrarti!";
                }
            }

            foreach (Persona p in Database.lstUtenti)
            {
                if (txtUsername.Text == p.Username && txtPassword.Text == p.Password)
                {
                    lblEsito.Text = "";
                    Session.Add("logged", true);
                    Session.Add("utente", p);
                    Response.Redirect("home.aspx");
                }
                else
                {
                    lblEsito.Text = "Devi Registrarti!";
                }
            }
        }
    }
}